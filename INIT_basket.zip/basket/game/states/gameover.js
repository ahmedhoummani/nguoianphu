
'use strict';
function GameOver() {}

GameOver.prototype = {
  preload: function () {

  },
  create: function () {

  },
  update: function () {

  }
};
module.exports = GameOver;

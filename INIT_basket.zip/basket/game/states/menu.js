
'use strict';
function Menu() {}

Menu.prototype = {
  preload: function() {

  },
  create: function() {
 
  },
  update: function() {

  }
};

module.exports = Menu;

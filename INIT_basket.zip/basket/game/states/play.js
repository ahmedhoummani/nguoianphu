
  'use strict';
  function Play() {}
  Play.prototype = {
    create: function() {

    },
    update: function() {

    }
	
  };
  
  module.exports = Play;